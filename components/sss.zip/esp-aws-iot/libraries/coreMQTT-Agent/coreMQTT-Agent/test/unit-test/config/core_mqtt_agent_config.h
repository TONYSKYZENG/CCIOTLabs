/* An empty config file for the unit test to compile with the default
 * definitions of configuration macros. */
